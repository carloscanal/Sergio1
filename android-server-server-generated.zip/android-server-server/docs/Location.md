
# Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **Double** |  |  [optional]
**longitude** | **Double** |  |  [optional]



