
# Temperature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**temperature** | **Double** |  |  [optional]



