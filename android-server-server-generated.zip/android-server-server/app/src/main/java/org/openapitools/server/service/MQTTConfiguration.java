package org.openapitools.server.service;

public class MQTTConfiguration {

    public static String MQTT_BROKER_URL = "tcp://YOUR MQTT BROKER IP:PORT";

}
